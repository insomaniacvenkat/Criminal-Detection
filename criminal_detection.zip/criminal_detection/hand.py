import sqlite3

def insertData(data):